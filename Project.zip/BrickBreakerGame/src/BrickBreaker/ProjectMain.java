package BrickBreaker;

import javax.swing.JFrame;

public class ProjectMain {

	public static void main(String[] args) {
		JFrame obj=new JFrame();    // code for setting frame for the game
		GamePlay gameplay=new GamePlay();    //created object for game play class
obj.setBounds(10,10,700,800);
obj.setTitle("Brick Breaker Game");
obj.setResizable(false);
obj.setVisible(true);
obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	obj.add(gameplay);
	}

}
